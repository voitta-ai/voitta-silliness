output "bucket_name" {
  description = "The S3 bucket where you upload the built site."
  value       = aws_s3_bucket.site.id
}

output "distribution_id" {
  description = "CloudFront distribution ID (for cache invalidations)."
  value       = aws_cloudfront_distribution.site.id
}

output "site_url" {
  description = "Public URL of the deployed calendar."
  value       = "https://${aws_cloudfront_distribution.site.domain_name}/"
}

output "embed_url" {
  description = "URL of the iframe-embeddable version."
  value       = "https://${aws_cloudfront_distribution.site.domain_name}/embed.html"
}
