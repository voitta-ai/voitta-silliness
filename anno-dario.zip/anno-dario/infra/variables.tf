variable "project_name" {
  description = "A short name used as prefix for resource names. Lowercase, no spaces."
  type        = string
  default     = "anno-dario"
}

variable "region" {
  description = "AWS region for the S3 bucket. CloudFront is global; this only affects S3."
  type        = string
  default     = "us-east-1"
}
